﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisGame
{
    public abstract class Tetromino
    {
        public int[,] Shape { get; protected set; }
        public int X { get; protected set; }
        public int Y { get; protected set; }
        public int Width => Shape.GetLength(0);
        public int Height => Shape.GetLength(1);

        public Tetromino()
        {
            X = 3;
            Y = 0;
        }

        public void MoveLeft()
        {
            X--;
        }

        public void MoveRight()
        {
            X++;
        }

        public void MoveDown()
        {
            Y++;
        }

        public void MoveUp()
        {
            Y--;
        }

        public void Rotate()
        {
            int[,] newShape = new int[Height, Width];

            for (int x = 0; x < Width; x++)
            {
                for (int y = 0; y < Height; y++)
                {
                    newShape[y, Width - 1 - x] = Shape[x, y];
                }
            }

            Shape = newShape;
        }

        public void RotateBack()
        {
            Rotate();
            Rotate();
            Rotate();
        }
    }
}
