﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisGame
{
    public class ITetromino : Tetromino
    {
        public ITetromino() : base()
        {
            Shape = new int[,]
            {
            { 0, 0, 0, 0 },
            { 1, 1, 1, 1 },
            { 0, 0, 0, 0 },
            { 0, 0, 0, 0 }
            };
        }
    }

    public class JTetromino : Tetromino
    {
        public JTetromino() : base()
        {
            Shape = new int[,]
            {
            { 2, 0, 0 },
            { 2, 2, 2 },
            { 0, 0, 0 }
            };
        }
    }

    public class LTetromino : Tetromino
    {
        public LTetromino() : base()
        {
            Shape = new int[,]
            {
            { 0, 0, 3 },
            { 3, 3, 3 },
            { 0, 0, 0 }
            };
        }
    }

    public class OTetromino : Tetromino
    {
        public OTetromino() : base()
        {
            Shape = new int[,]
            {
            { 4, 4 },
            { 4, 4 }
            };
        }
    }

    public class STetromino : Tetromino
    {
        public STetromino() : base()
        {
            Shape = new int[,]
            {
            { 0, 5, 5 },
            { 5, 5, 0 },
            { 0, 0, 0 }
            };
        }
    }

    public class TTetromino : Tetromino
    {
        public TTetromino() : base()
        {
            Shape = new int[,]
            {
            { 0, 6, 0 },
            { 6, 6, 6 },
            { 0, 0, 0 }
            };
        }
    }

    public class ZTetromino : Tetromino
    {
        public ZTetromino() : base()
        {
            Shape = new int[,]
            {
            { 7, 7, 0 },
            { 0, 7, 7 },
            { 0, 0, 0 }
            };
        }
    }
}
