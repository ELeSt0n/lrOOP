﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisGame
{
    public class Game
    {
        private const int GridWidth = 10;
        private const int GridHeight = 20;
        private const int BlockSize = 30;

        private int[,] grid;
        private Tetromino currentPiece;
        private Tetromino nextPiece;
        private int score;
        private int level;
        private int linesCleared;
        private bool isGameOver;
        private Random random;

        public int Score => score;
        public int Level => level;
        public int LinesCleared => linesCleared;
        public bool IsGameOver => isGameOver;
        public Tetromino NextPiece => nextPiece;
        public int[,] Grid => grid;

        public event Action OnGameOver;
        public event Action OnUpdate;

        public Game()
        {
            grid = new int[GridWidth, GridHeight];
            random = new Random();
            score = 0;
            level = 1;
            linesCleared = 0;
            isGameOver = false;

            currentPiece = CreateRandomTetromino();
            nextPiece = CreateRandomTetromino();
        }

        public void Start()
        {
            isGameOver = false;
            score = 0;
            level = 1;
            linesCleared = 0;
            ClearGrid();

            currentPiece = CreateRandomTetromino();
            nextPiece = CreateRandomTetromino();

            OnUpdate?.Invoke();
        }

        private void ClearGrid()
        {
            for (int x = 0; x < GridWidth; x++)
            {
                for (int y = 0; y < GridHeight; y++)
                {
                    grid[x, y] = 0;
                }
            }
        }

        private Tetromino CreateRandomTetromino()
        {
            int type = random.Next(7);
            return type switch
            {
                0 => new ITetromino(),
                1 => new JTetromino(),
                2 => new LTetromino(),
                3 => new OTetromino(),
                4 => new STetromino(),
                5 => new TTetromino(),
                6 => new ZTetromino(),
                _ => new OTetromino()
            };
        }

        public void Update()
        {
            if (isGameOver) return;

            currentPiece.MoveDown();

            if (!IsValidPosition(currentPiece))
            {
                currentPiece.MoveUp();
                MergePiece();
                ClearLines();

                currentPiece = nextPiece;
                nextPiece = CreateRandomTetromino();

                if (!IsValidPosition(currentPiece))
                {
                    isGameOver = true;
                    OnGameOver?.Invoke();
                }
            }

            OnUpdate?.Invoke();
        }

        public void MoveLeft()
        {
            if (isGameOver) return;

            currentPiece.MoveLeft();
            if (!IsValidPosition(currentPiece))
                currentPiece.MoveRight();

            OnUpdate?.Invoke();
        }

        public void MoveRight()
        {
            if (isGameOver) return;

            currentPiece.MoveRight();
            if (!IsValidPosition(currentPiece))
                currentPiece.MoveLeft();

            OnUpdate?.Invoke();
        }

        public void Rotate()
        {
            if (isGameOver) return;

            currentPiece.Rotate();
            if (!IsValidPosition(currentPiece))
                currentPiece.RotateBack();

            OnUpdate?.Invoke();
        }

        public void Drop()
        {
            if (isGameOver) return;

            while (IsValidPosition(currentPiece))
            {
                currentPiece.MoveDown();
            }

            currentPiece.MoveUp();
            MergePiece();
            ClearLines();

            currentPiece = nextPiece;
            nextPiece = CreateRandomTetromino();

            if (!IsValidPosition(currentPiece))
            {
                isGameOver = true;
                OnGameOver?.Invoke();
            }

            OnUpdate?.Invoke();
        }

        private bool IsValidPosition(Tetromino piece)
        {
            for (int x = 0; x < piece.Width; x++)
            {
                for (int y = 0; y < piece.Height; y++)
                {
                    if (piece.Shape[x, y] == 0) continue;

                    int gridX = piece.X + x;
                    int gridY = piece.Y + y;

                    if (gridX < 0 || gridX >= GridWidth || gridY < 0 || gridY >= GridHeight)
                        return false;

                    if (grid[gridX, gridY] != 0)
                        return false;
                }
            }

            return true;
        }

        private void MergePiece()
        {
            for (int x = 0; x < currentPiece.Width; x++)
            {
                for (int y = 0; y < currentPiece.Height; y++)
                {
                    if (currentPiece.Shape[x, y] != 0)
                    {
                        int gridX = currentPiece.X + x;
                        int gridY = currentPiece.Y + y;
                        grid[gridX, gridY] = currentPiece.Shape[x, y];
                    }
                }
            }
        }

        private void ClearLines()
        {
            int linesClearedThisTurn = 0;

            for (int y = GridHeight - 1; y >= 0; y--)
            {
                bool lineComplete = true;
                for (int x = 0; x < GridWidth; x++)
                {
                    if (grid[x, y] == 0)
                    {
                        lineComplete = false;
                        break;
                    }
                }

                if (lineComplete)
                {
                    linesClearedThisTurn++;
                    for (int yy = y; yy > 0; yy--)
                    {
                        for (int x = 0; x < GridWidth; x++)
                        {
                            grid[x, yy] = grid[x, yy - 1];
                        }
                    }

                    for (int x = 0; x < GridWidth; x++)
                    {
                        grid[x, 0] = 0;
                    }

                    y++; // Check the same line again
                }
            }

            if (linesClearedThisTurn > 0)
            {
                linesCleared += linesClearedThisTurn;
                score += CalculateScore(linesClearedThisTurn);
                level = linesCleared / 10 + 1;
            }
        }

        private int CalculateScore(int lines)
        {
            return lines switch
            {
                1 => 100 * level,
                2 => 300 * level,
                3 => 500 * level,
                4 => 800 * level,
                _ => 0
            };
        }

        public void Draw(Graphics g, int offsetX, int offsetY)
        {
            // Draw grid background
            g.FillRectangle(Brushes.Black, offsetX, offsetY, GridWidth * BlockSize, GridHeight * BlockSize);

            // Draw grid lines
            for (int x = 0; x <= GridWidth; x++)
            {
                g.DrawLine(Pens.Gray, offsetX + x * BlockSize, offsetY, offsetX + x * BlockSize, offsetY + GridHeight * BlockSize);
            }

            for (int y = 0; y <= GridHeight; y++)
            {
                g.DrawLine(Pens.Gray, offsetX, offsetY + y * BlockSize, offsetX + GridWidth * BlockSize, offsetY + y * BlockSize);
            }

            // Draw merged pieces
            for (int x = 0; x < GridWidth; x++)
            {
                for (int y = 0; y < GridHeight; y++)
                {
                    if (grid[x, y] != 0)
                    {
                        DrawBlock(g, offsetX + x * BlockSize, offsetY + y * BlockSize, grid[x, y]);
                    }
                }
            }

            // Draw current piece
            if (!isGameOver)
            {
                for (int x = 0; x < currentPiece.Width; x++)
                {
                    for (int y = 0; y < currentPiece.Height; y++)
                    {
                        if (currentPiece.Shape[x, y] != 0)
                        {
                            int drawX = offsetX + (currentPiece.X + x) * BlockSize;
                            int drawY = offsetY + (currentPiece.Y + y) * BlockSize;
                            DrawBlock(g, drawX, drawY, currentPiece.Shape[x, y]);
                        }
                    }
                }
            }
        }

        private void DrawBlock(Graphics g, int x, int y, int colorIndex)
        {
            Color[] colors = new Color[]
            {
            Color.Transparent, // Shouldn't be used
            Color.Cyan,        // I
            Color.Blue,       // J
            Color.Orange,      // L
            Color.Yellow,      // O
            Color.Green,      // S
            Color.Purple,      // T
            Color.Red          // Z
            };

            Brush brush = new SolidBrush(colors[colorIndex]);
            g.FillRectangle(brush, x + 1, y + 1, BlockSize - 2, BlockSize - 2);
            g.DrawRectangle(Pens.White, x + 1, y + 1, BlockSize - 2, BlockSize - 2);
        }

        public void DrawNextPiece(Graphics g, int offsetX, int offsetY)
        {
            int previewSize = 5 * BlockSize;
            g.FillRectangle(Brushes.Black, offsetX, offsetY, previewSize, previewSize);

            if (nextPiece == null) return;

            // Center the piece in the preview area
            int startX = offsetX + (previewSize - nextPiece.Width * BlockSize) / 2;
            int startY = offsetY + (previewSize - nextPiece.Height * BlockSize) / 2;

            for (int x = 0; x < nextPiece.Width; x++)
            {
                for (int y = 0; y < nextPiece.Height; y++)
                {
                    if (nextPiece.Shape[x, y] != 0)
                    {
                        DrawBlock(g, startX + x * BlockSize, startY + y * BlockSize, nextPiece.Shape[x, y]);
                    }
                }
            }
        }
    }
}
