namespace TetrisGame
{
    using System;
    using System.Drawing;
    using System.Windows.Forms;

    public class MainForm : Form
    {
        private Game game;
        private Timer gameTimer;
        private Button startButton;
        private Label scoreLabel;
        private Label levelLabel;
        private Label linesLabel;
        private PictureBox gameBoard;
        private PictureBox nextPieceBox;

        public MainForm()
        {
            InitializeComponents();
            InitializeGame();
        }

        private void InitializeComponents()
        {
            // ������������ �����
            this.Text = "����� ��� �������� 101-���";
            this.ClientSize = new Size(500, 600);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // ��������� �������� ���������
            gameBoard = new PictureBox
            {
                Location = new Point(20, 20),
                Size = new Size(300, 600),
                BackColor = Color.Black,
                BorderStyle = BorderStyle.Fixed3D
            };

            nextPieceBox = new PictureBox
            {
                Location = new Point(340, 100),
                Size = new Size(150, 150),
                BackColor = Color.Black,
                BorderStyle = BorderStyle.Fixed3D
            };

            startButton = new Button
            {
                Location = new Point(340, 20),
                Size = new Size(150, 40),
                Text = "���� ���",
                Font = new Font("Arial", 12)
            };

            scoreLabel = new Label
            {
                Location = new Point(340, 280),
                Size = new Size(150, 30),
                Text = "����: 0",
                Font = new Font("Arial", 12),
                ForeColor = Color.White,
                BackColor = Color.Black
            };

            levelLabel = new Label
            {
                Location = new Point(340, 320),
                Size = new Size(150, 30),
                Text = "г����: 1",
                Font = new Font("Arial", 12),
                ForeColor = Color.White,
                BackColor = Color.Black
            };

            linesLabel = new Label
            {
                Location = new Point(340, 360),
                Size = new Size(150, 30),
                Text = "˳���: 0",
                Font = new Font("Arial", 12),
                ForeColor = Color.White,
                BackColor = Color.Black
            };

            Label nextLabel = new Label
            {
                Location = new Point(340, 70),
                Size = new Size(150, 30),
                Text = "��������:",
                Font = new Font("Arial", 12),
                ForeColor = Color.White,
                BackColor = Color.Black
            };

            // ������ �������� �� �����
            this.Controls.AddRange(new Control[] {
            gameBoard,
            nextPieceBox,
            startButton,
            scoreLabel,
            levelLabel,
            linesLabel,
            nextLabel
        });

            // ���������� ������
            gameTimer = new Timer { Interval = 500 };

            // ������ ���� �������������� ������
            startButton.Click += StartButton_Click;
            gameTimer.Tick += GameTimer_Tick;
            gameBoard.Paint += GameBoard_Paint;
            nextPieceBox.Paint += NextPieceBox_Paint;

            // ������������ �����
            this.KeyPreview = true;
            this.PreviewKeyDown += MainForm_PreviewKeyDown;
        }

        private void InitializeGame()
        {
            game = new Game();
            game.OnUpdate += Game_OnUpdate;
            game.OnGameOver += Game_OnGameOver;
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            game.Start();
            gameTimer.Start();
            this.Focus(); //  ����� �� ����� ���� ������ ���
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            game.Update();
        }

        private void Game_OnUpdate()
        {
            scoreLabel.Text = $"����: {game.Score}";
            levelLabel.Text = $"г����: {game.Level}";
            linesLabel.Text = $"˳���: {game.LinesCleared}";

            gameBoard.Invalidate();
            nextPieceBox.Invalidate();

            gameTimer.Interval = Math.Max(100, 500 - (game.Level - 1) * 50);
        }

        private void Game_OnGameOver()
        {
            gameTimer.Stop();
            MessageBox.Show($"��� ��������!\nԳ������� �������: {game.Score}", "�����");
        }

        private void GameBoard_Paint(object sender, PaintEventArgs e)
        {
            if (game != null)
                game.Draw(e.Graphics, 0, 0);
        }

        private void NextPieceBox_Paint(object sender, PaintEventArgs e)
        {
            if (game != null)
                game.DrawNextPiece(e.Graphics, 0, 0);
        }

        private void MainForm_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (game == null || game.IsGameOver) return;

            switch (e.KeyCode)
            {
                case Keys.Left:
                case Keys.Right:
                case Keys.Up:
                case Keys.Down:
                case Keys.Space:
                    e.IsInputKey = true;
                    break;
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (game == null || game.IsGameOver)
                return base.ProcessCmdKey(ref msg, keyData);

            switch (keyData)
            {
                case Keys.Left:
                    game.MoveLeft();
                    return true;
                case Keys.Right:
                    game.MoveRight();
                    return true;
                case Keys.Down:
                    game.Update();
                    return true;
                case Keys.Up:
                    game.Rotate();
                    return true;
                case Keys.Space:
                    game.Drop();
                    return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}