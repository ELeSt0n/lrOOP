﻿using System;

class Program
{
    static double CalculateGeometricSum(double a, double r, int n)
    {
        if (r == 1)
        {
            return a * n; // Якщо r = 1, сума просто n * a
        }
        else
        {
            return a * (1 - Math.Pow(r, n)) / (1 - r); // Формула для суми геометричної прогресії
        }
    }

    static void Main(string[] args)
    {
        // Введення параметрів геометричної прогресії
        Console.WriteLine("Введіть перший елемент прогресії (a):");
        double a = double.Parse(Console.ReadLine());

        Console.WriteLine("Введіть знаменник прогресії (r):");
        double r = double.Parse(Console.ReadLine());

        Console.WriteLine("Введіть кількість елементів прогресії (n):");
        int n = int.Parse(Console.ReadLine());

        // Обчислення суми геометричної прогресії
        double sum = CalculateGeometricSum(a, r, n);

        // Виведення результату
        Console.WriteLine($"Сума геометричної прогресії: {sum}");
    }
}
