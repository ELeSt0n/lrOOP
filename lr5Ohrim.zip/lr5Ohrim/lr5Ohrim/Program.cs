﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Введення рядка
        Console.WriteLine("Введіть рядок:");
        string input = Console.ReadLine();

        // Видалення всіх пробілів
        string result = input.Replace(" ", "");

        // Виведення результату
        Console.WriteLine("Рядок без пробілів:");
        Console.WriteLine(result);
    }
}
