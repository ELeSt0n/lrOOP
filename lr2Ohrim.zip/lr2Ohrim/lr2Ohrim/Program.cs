﻿using System;

class IntegerArray
{
    private int[] array;
    private int lowerBound;
    private int upperBound;

    // Конструктор для створення масиву з довільними межами індексів
    public IntegerArray(int lowerBound, int upperBound)
    {
        if (lowerBound > upperBound)
            throw new ArgumentException("Нижня межа індексу не може бути більшою за верхню.");

        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
        this.array = new int[upperBound - lowerBound + 1];
    }

    // Властивість для доступу до елементів масиву з контролем індексів
    public int this[int index]
    {
        get
        {
            if (index < lowerBound || index > upperBound)
                throw new IndexOutOfRangeException("Індекс вийшов за межі масиву.");
            return array[index - lowerBound];
        }
        set
        {
            if (index < lowerBound || index > upperBound)
                throw new IndexOutOfRangeException("Індекс вийшов за межі масиву.");
            array[index - lowerBound] = value;
        }
    }

    // Операція поелементного додавання масивів
    public void Add(IntegerArray other)
    {
        if (other.lowerBound != this.lowerBound || other.upperBound != this.upperBound)
            throw new ArgumentException("Масиви повинні мати однакові межі індексів для додавання.");

        for (int i = lowerBound; i <= upperBound; i++)
        {
            this[i] += other[i];
        }
    }

    // Операція поелементного віднімання масивів
    public void Subtract(IntegerArray other)
    {
        if (other.lowerBound != this.lowerBound || other.upperBound != this.upperBound)
            throw new ArgumentException("Масиви повинні мати однакові межі індексів для віднімання.");

        for (int i = lowerBound; i <= upperBound; i++)
        {
            this[i] -= other[i];
        }
    }

    // Множення всіх елементів масиву на скаляр
    public void MultiplyByScalar(int scalar)
    {
        for (int i = lowerBound; i <= upperBound; i++)
        {
            this[i] *= scalar;
        }
    }

    // Ділення всіх елементів масиву на скаляр
    public void DivideByScalar(int scalar)
    {
        if (scalar == 0)
            throw new DivideByZeroException("Не можна ділити на 0.");

        for (int i = lowerBound; i <= upperBound; i++)
        {
            this[i] /= scalar;
        }
    }

    // Виведення всього масиву
    public void PrintArray()
    {
        for (int i = lowerBound; i <= upperBound; i++)
        {
            Console.WriteLine($"index {i}: {this[i]}");
        }
    }

    // Виведення елементів масиву за індексами
    public void PrintElementAtIndex(int index)
    {
        try
        {
            Console.WriteLine($"Елемент за індексом {index}: {this[index]}");
        }
        catch (IndexOutOfRangeException)
        {
            Console.WriteLine("Індекс вийшов за межі масиву.");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Створення двох масивів з різними межами індексів
        IntegerArray array1 = new IntegerArray(1, 5);
        IntegerArray array2 = new IntegerArray(1, 5);

        // Заповнення масивів
        for (int i = 1; i <= 5; i++)
        {
            array1[i] = i * 2;  // Масив 1: [2, 4, 6, 8, 10]
            array2[i] = i;      // Масив 2: [1, 2, 3, 4, 5]
        }

        // Виведення елементів масиву
        Console.WriteLine("Масив 1:");
        array1.PrintArray();

        Console.WriteLine("Масив 2:");
        array2.PrintArray();

        // Додавання масивів
        array1.Add(array2);
        Console.WriteLine("\nПісля додавання масивів:");
        array1.PrintArray();

        // Віднімання масивів
        array1.Subtract(array2);
        Console.WriteLine("\nПісля віднімання масивів:");
        array1.PrintArray();

        // Множення на скаляр
        array1.MultiplyByScalar(3);
        Console.WriteLine("\nПісля множення на скаляр 3:");
        array1.PrintArray();

        // Ділення на скаляр
        array1.DivideByScalar(2);
        Console.WriteLine("\nПісля ділення на скаляр 2:");
        array1.PrintArray();

        // Виведення елемента за індексом
        array1.PrintElementAtIndex(3);  // Виведе елемент на індекс 3

        // Спроба звернутися до елемента за межами масиву
        array1.PrintElementAtIndex(6);  // Виведе повідомлення про помилку
    }
}
