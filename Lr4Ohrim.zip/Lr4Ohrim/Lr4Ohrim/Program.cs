﻿using System;

class Program
{
    // Завдання 1
    static void Task1()
    {
        // Введення масиву
        Console.WriteLine("Введіть кількість елементів масиву n:");
        int n = int.Parse(Console.ReadLine());
        double[] array = new double[n];

        Console.WriteLine("Введіть елементи масиву:");
        for (int i = 0; i < n; i++)
        {
            array[i] = double.Parse(Console.ReadLine());
        }

        // Введення числа C
        Console.WriteLine("Введіть число C:");
        double C = double.Parse(Console.ReadLine());

        // а) Кількість елементів масиву, більших за число C
        int countGreaterThanC = 0;
        foreach (double num in array)
        {
            if (num > C)
                countGreaterThanC++;
        }
        Console.WriteLine($"Кількість елементів масиву, більших за число C: {countGreaterThanC}");

        // б) Добуток елементів масиву, розташованих після максимального за модулем елемента
        double maxAbsValue = Math.Abs(array[0]);
        int maxIndex = 0;
        for (int i = 1; i < n; i++)
        {
            if (Math.Abs(array[i]) > maxAbsValue)
            {
                maxAbsValue = Math.Abs(array[i]);
                maxIndex = i;
            }
        }

        double product = 1;
        for (int i = maxIndex + 1; i < n; i++)
        {
            product *= array[i];
        }
        Console.WriteLine($"Добуток елементів масиву після максимального за модулем елемента: {product}");

        // в) Перетворення масиву (від’ємні елементи спочатку, потім додатні)
        Array.Sort(array, (x, y) => x.CompareTo(y));

        Console.WriteLine("Масив після перетворення (від’ємні спочатку, потім додатні):");
        foreach (var item in array)
        {
            Console.WriteLine(item);
        }
    }

    // Завдання 2
    static void Task2()
    {
        // Введення розмірів масиву
        Console.WriteLine("Введіть кількість рядків:");
        int rows = int.Parse(Console.ReadLine());
        Console.WriteLine("Введіть кількість стовпців:");
        int cols = int.Parse(Console.ReadLine());

        // Створення двовимірного масиву
        int[,] matrix = new int[rows, cols];

        Console.WriteLine("Введіть елементи масиву:");
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                matrix[i, j] = int.Parse(Console.ReadLine());
            }
        }

        // а) Заміна значення елемента п’ятого рядка на число 2012 (індексуємо з 0)
        Console.WriteLine("Введіть номер стовпця для заміни в п’ятому рядку:");
        int column = int.Parse(Console.ReadLine());
        if (column >= 0 && column < cols && rows >= 5)
        {
            matrix[4, column] = 2012;
            Console.WriteLine("Заміна елемента на 2012 виконана.");
        }
        else
        {
            Console.WriteLine("Невірний стовпець або недостатньо рядків.");
        }

        // б) Заміна значення будь-якого елемента масиву на число a
        Console.WriteLine("Введіть номер рядка для заміни:");
        int row = int.Parse(Console.ReadLine());
        Console.WriteLine("Введіть номер стовпця для заміни:");
        column = int.Parse(Console.ReadLine());
        Console.WriteLine("Введіть число для заміни:");
        int a = int.Parse(Console.ReadLine());

        if (row >= 0 && row < rows && column >= 0 && column < cols)
        {
            matrix[row, column] = a;
            Console.WriteLine("Заміна елемента виконана.");
        }
        else
        {
            Console.WriteLine("Невірні індекси для заміни.");
        }

        // Виведення результату
        Console.WriteLine("Масив після змін:");
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                Console.Write(matrix[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }

    static void Main(string[] args)
    {
        // Виконання завдання 1
        Task1();

        // Виконання завдання 2
        Task2();
    }
}
