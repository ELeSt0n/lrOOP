﻿using System;

public abstract class Root
{
    // Абстрактні методи для обчислення кореня та виведення результату
    public abstract void CalculateRoot();
    public abstract void DisplayResult();
}

public class Linear : Root
{
    private double a, b;
    private double root;

    public Linear(double a, double b)
    {
        this.a = a;
        this.b = b;
    }

    // Метод для обчислення кореня лінійного рівняння
    public override void CalculateRoot()
    {
        if (a == 0)
        {
            if (b == 0)
                Console.WriteLine("Рівняння має безліч розв'язків.");
            else
                Console.WriteLine("Рівняння не має розв'язків.");
        }
        else
        {
            root = -b / a;  // Обчислюємо корінь лінійного рівняння ax + b = 0
        }
    }

    // Метод для виведення результату
    public override void DisplayResult()
    {
        Console.WriteLine("Корінь лінійного рівняння: " + root);
    }
}

public class Square : Root
{
    private double a, b, c;
    private double discriminant;
    private double root1, root2;

    public Square(double a, double b, double c)
    {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    // Метод для обчислення коренів квадратного рівняння
    public override void CalculateRoot()
    {
        discriminant = b * b - 4 * a * c;

        if (discriminant > 0)
        {
            root1 = (-b + Math.Sqrt(discriminant)) / (2 * a);
            root2 = (-b - Math.Sqrt(discriminant)) / (2 * a);
        }
        else if (discriminant == 0)
        {
            root1 = -b / (2 * a);
        }
        else
        {
            Console.WriteLine("Рівняння не має дійсних коренів.");
        }
    }

    // Метод для виведення результату
    public override void DisplayResult()
    {
        if (discriminant > 0)
        {
            Console.WriteLine($"Корені квадратного рівняння: x1 = {root1}, x2 = {root2}");
        }
        else if (discriminant == 0)
        {
            Console.WriteLine($"Єдиний корінь квадратного рівняння: x = {root1}");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Приклад для лінійного рівняння
        Console.WriteLine("Лінійне рівняння:");
        Linear linear = new Linear(2, -4);
        linear.CalculateRoot();
        linear.DisplayResult();

        // Приклад для квадратного рівняння
        Console.WriteLine("\nКвадратне рівняння:");
        Square square = new Square(1, -3, 2);
        square.CalculateRoot();
        square.DisplayResult();
    }
}
